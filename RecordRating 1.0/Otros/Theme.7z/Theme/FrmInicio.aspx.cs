﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FrmInicio : System.Web.UI.Page
{
    public string sUser = "jperez", sPass = "123";
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }


    protected void z_btnAceptar_Click(object sender, EventArgs e)
    {
        if (sUser.Equals(username.Value.ToString()) && sPass.Equals(password.Value.ToString()))
        {
            HttpCookie cookie = Request.Cookies["User"];
            if (cookie == null)
                cookie = new HttpCookie("User");
            cookie["Nombre"] = "Jonathan Perez";
            cookie["Id"] = sPass;
            Response.Cookies.Add(cookie);
            Response.Redirect("MaquetaPrincipal.aspx");
        }
    }
}