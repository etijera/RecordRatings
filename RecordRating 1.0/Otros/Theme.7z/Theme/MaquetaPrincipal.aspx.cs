﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MaquetaPrincipal : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie cookie = Request.Cookies["User"];

        if (cookie == null)
            Response.Redirect("FrmInicio.aspx");
        else
            this.Header.Title = cookie["Nombre"].ToString();
    }

    protected void z_btnCerrar_Click(object sender, EventArgs e)
    {
        HttpCookie myCookie = new HttpCookie("User");
        myCookie.Expires = DateTime.Now.AddDays(-1d);
        Response.Cookies.Add(myCookie);
        Response.Redirect("FrmInicio.aspx");
    }
}